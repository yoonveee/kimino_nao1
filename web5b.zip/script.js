function calculateAreaHeron() {
    const a = parseFloat(document.getElementById('side1').value);
    const b = parseFloat(document.getElementById('side2').value);
    const c = parseFloat(document.getElementById('side3').value);
    
    if (isNaN(a) || isNaN(b) || isNaN(c) || a <= 0 || b <= 0 || c <= 0) {
        alert('Please enter the correct values for the sides of the triangle');
        return;
    }

    const s = (a + b + c) / 2;
    const area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
    
    document.getElementById('result').innerText =  `Result: ${area.toFixed(1)}`;
}

function calculateAreaAngle(){
  const side1 = parseFloat(document.getElementById('2side1').value);
  const side2 = parseFloat(document.getElementById('2side2').value);
  const angle = parseFloat(document.getElementById('angle').value);

  if (isNaN(side1) || isNaN(side2) || isNaN(angle) || side1 <= 0 || side2 <= 0 || angle >= 180 ){
    alert('Please enter the correct values ​​for the sides of the triangle and the angle.');
    return;
  }

  const radians = angle * (Math.PI / 180);
  const area = (side1 * side2 * Math.sin(radians)) / 2;

  document.getElementById('result2').innerText = `Result: ${area.toFixed(1)}`;

}


function calculateAreaHeight(){
    const side = parseFloat(document.getElementById('3side').value);
    const height = parseFloat(document.getElementById('height').value);

    if(isNaN(side) || isNaN(height) || side <= 0 || height <= 0){
        alert('Please enter the correct values ​​for the side and height of the triangle.');
        return;
    }

    const area = (side * height)/2;

    document.getElementById('result3').innerText = `Result: ${area.toFixed(1)}`;
}

function calculateAreaRadius(){
  const a = parseFloat(document.getElementById('4side1').value);
  const b = parseFloat(document.getElementById('4side2').value);
  const c = parseFloat(document.getElementById('4side3').value);
  const radius = parseFloat(document.getElementById('radius').value);

  if(isNaN(a) || isNaN(b) || isNaN(c) || isNaN(radius) || a <= 0 || b <= 0 || c <= 0 || radius <= 0){
    alert('Please enter the correct values ​​for the sides of the triangle and the radius of the described circle.');
    return;
  }


  const semiperimeter = (a + b + c) / 2;
  const area = (a * b * c) / (4 * Math.sqrt(semiperimeter * (semiperimeter - a) * (semiperimeter - b) * (semiperimeter - c)));
  
  document.getElementById('result4').innerText = `Result: ${area.toFixed(1)}`;

}

function checkParindrome(){
  const number = parseInt(document.getElementById('5number').value);
  
  if(isNaN(number) || number === ''){
    alert('Please enter a valid number.');
    return;
  }
 
  const reversedNumber = parseInt(number.toString().split('').reverse().join(''));
   
  if(number === reversedNumber){
    document.getElementById('check').innerText = `${number} is Palindrom number`;
  } else {
    document.getElementById('check').innerText = `${number} is Not Palindrome number`;
  }
}
 

function checkAnagram() {
  const word1 = document.getElementById('word1').value.toLowerCase().replace(/\s/g, '');  // конвертуємо в нижній регістр і видаляємо пробіли
  const word2 = document.getElementById('word2').value.toLowerCase().replace(/\s/g, '');

  if (word1.length === 0 || word2.length === 0) {
      alert("Please enter both words.");
      return;
  }

  const sortedWord1 = word1.split('').sort().join(''); 
  const sortedWord2 = word2.split('').sort().join('');

  if (sortedWord1 === sortedWord2) {
      document.getElementById('result6').innerText = 'This is Anagrama';
  } else {
      document.getElementById('result6').innerText = 'This is Not Anagrama';
  }
  
}


function calculateFibonacci() {
  const n = parseInt(document.getElementById('fibonacciNumber').value);
  if (isNaN(n) || n <= 0) {
      alert("Please enter the correct serial number of the number.");
      return;
  }

  const result = fibonacci(n);

  document.getElementById('result7').innerText = `Fibonacci number with sequence number ${n}: ${result}`;
}

function fibonacci(n) {
  if (n <= 1) {
      return n;
  } else {
      return fibonacci(n - 1) + fibonacci(n - 2);
  }
}


function checkFibonacci() {
  const inputElement = document.getElementById('fibonacciNumber2');
  const number = parseInt(inputElement.value);

   
  if (isNaN(number) || !Number.isInteger(number) || number <= 0) {
      alert("Please enter the correct serial number of the number. ");
      return;
  }
 
  const isInFibonacciSequence = isFibonacciNumber(number);
 
  if (isInFibonacciSequence) {
      document.getElementById('result8').innerText = `${number}: belongs to the Fibonacci sequence.`;
  } else {
      document.getElementById('result8').innerText = `${number}: does not belong to the Fibonacci sequence.`;
  }
}

function isFibonacciNumber(number) { 
  return isPerfectSquare(5 * number * number + 4) || isPerfectSquare(5 * number * number - 4);
}

function isPerfectSquare(x) {
  const sqrtX = Math.sqrt(x);
  return sqrtX === Math.floor(sqrtX);
}
